import React from "react";
import { useCartContext } from "../Contex/Cart_Contex"; // Import the context

export default function Checkout() {
  // Use the cart from the context
  const { cart } = useCartContext();

  // Calculate total
  const totalPrice = cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );
  const shippingPrice = 100;
  const finalAmount = totalPrice + shippingPrice;

  // Razorpay payment handler (Frontend-only)
  const handlePayment = () => {
    const options = {
      key: "rzp_test_ABC123xyz", // Replace with your Razorpay Test Key ID
      amount: finalAmount * 100, // Amount in paise
      currency: "INR",
      name: "My Shop",
      description: "Test Order (Frontend-only Demo)",
      handler: function (response) {
        alert(
          "Payment simulated!\nPayment ID: " + response.razorpay_payment_id
        );
        console.log("Response:", response);
      },
      prefill: {
        name: "Sneha Tiwari",
        email: "sneha@example.com",
        contact: "9876543210",
      },
      theme: {
        color: "#3399cc",
      },
    };

    const rzp = new window.Razorpay(options);
    rzp.open();

    // Catch failures (will always fail in frontend-only mode)
    rzp.on("payment.failed", function (response) {
      alert("Payment Failed ❌ (because no backend order_id is used).");
      console.log("Failure details:", response.error);
    });
  };

  // Background style
  const backgroundStyle = {
    backgroundImage: `url(${process.env.PUBLIC_URL}/Assets/bg.jpg)`,
    backgroundSize: "cover",
    backgroundPosition: "center",
    height: "auto",
    position: "relative",
  };

  const overlayStyle = {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "rgba(0, 0, 0, 0.6)",
    zIndex: 0,
  };

  return (
    <div style={backgroundStyle}>
      <div style={overlayStyle}></div>
      <div className="Main" style={{ position: "relative", zIndex: "5" }}>
        <div className="container row" style={{ color: "white" }}>
          <div className="col-lg-6 p-4">
            <h6>Shipping Address</h6>
            <form className="form-horizontal">
              <div className="form-group mb-3">
                <div className="col-sm-12">
                  <h6>Enter Here Name</h6>
                  <input
                    type="text"
                    className="form-control"
                    required
                    style={{
                      backgroundColor: "transparent",
                      color: "white",
                      border: "1px solid lightgray",
                    }}
                  />
                </div>
              </div>

              <div className="form-group mb-3">
                <div className="col-sm-12">
                  <h6>Enter Here Email</h6>
                  <input
                    type="email"
                    className="form-control"
                    required
                    style={{
                      backgroundColor: "transparent",
                      color: "white",
                      border: "1px solid lightgray",
                    }}
                  />
                </div>
              </div>

              <div className="form-group mb-3">
                <div className="col-sm-12">
                  <h6>Enter Here Number</h6>
                  <input
                    type="text"
                    className="form-control"
                    required
                    style={{
                      backgroundColor: "transparent",
                      color: "white",
                      border: "1px solid lightgray",
                    }}
                  />
                </div>
              </div>

              <h6>Enter Here Message</h6>
              <textarea
                className="form-control mb-3"
                rows="4"
                required
                style={{
                  backgroundColor: "transparent",
                  color: "white",
                  border: "1px solid lightgray",
                }}
              ></textarea>

              {/* 🔥 Payment button with Razorpay */}
              <button
                type="button"
                onClick={handlePayment}
                style={{
                  backgroundColor: "transparent",
                  color: "white",
                  border: "1px solid lightgray",
                  padding: "10px 20px",
                  cursor: "pointer",
                }}
              >
                Pay {finalAmount} ₹
              </button>
            </form>
          </div>

          <div className="col-md-2"></div>
          <div className="col-lg-4">
            <div className="p-5" style={{ border: "1px solid lightgray" }}>
              <h6>
                Subtotal:{" "}
                <span style={{ fontSize: "24px", fontWeight: "bold" }}>
                  {totalPrice.toFixed(2)} ₹
                </span>
              </h6>
              <h6>
                Shipping Price:{" "}
                <span style={{ fontSize: "23px" }}>{shippingPrice} ₹</span>
              </h6>
              <h6>
                Total Price:{" "}
                <span style={{ fontSize: "23px" }}>{finalAmount} ₹</span>
              </h6>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
